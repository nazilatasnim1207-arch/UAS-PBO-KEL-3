/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package Util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author Nazila T
 * NIM = 25104410005
 * Kelas = Teknik Informatika
 */
public class DBConection {

    static final String DB_URL ="JDBC:mysql://localhost:3306/db_toko";
    static final String DB_user = "root";
    static final String DB_PASS ="";
    
    public static void main(String[] args) {
        Connection conn = getKoneksi(); // 
        if(conn !=null){
            try{
                conn.close();
                System.out.println("koneksi ditutup");
            }
            catch(SQLException e){
                System.err.println("ERROR SAAT MENUTUP KONEKSI");
            }
        }
    }

    public static Connection getKoneksi() { // retrun
        Connection conn = null;
        try { // satu paket dengan cacth 
            conn = DriverManager.getConnection(DB_URL,DB_user,DB_PASS);
            if(conn!=null){
                //disini ada koneksi
                System.out.println("koneksi berhasil");
                //
                
            }else {
                System.out.println("koneksi tidak berhasil");
            }
        }
        catch(SQLException e){
            System.err.println("Error koneksi ke database gagal"+e.getMessage());
        }
        return conn;
    }
}
 