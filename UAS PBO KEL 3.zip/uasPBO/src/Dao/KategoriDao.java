/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package Dao;

import Model.Kategori;
import Util.DBConection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JTable;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author Nazila T
 * NIM = 25104410005
 * Kelas = Teknik Informatika
 */
public class KategoriDao {
    
    Connection conn = DBConection.getKoneksi();
    
    // LOAD DATA
    public void loadData(JTable table) {

        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("kode");
        model.addColumn("kategori");
        model.addColumn("brand");

        try {
            String sql = "SELECT p.kode"
                    + "k.kategori, k.brand "
                    + "FROM produk p "
                    + "JOIN kategori k ON p.kode_produk = k.kode";

            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                model.addRow(new Object[]{
                    rs.getInt("kode"),
                    rs.getString("kategori"),
                    rs.getString("brand")
                });
            }

            table.setModel(model);

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }

    public void insert(Kategori k){

    try{

        // Mengecek apakah kombinasi kategori dan brand sudah ada
        String cek =
        "SELECT * FROM kategori WHERE kategori=? AND brand=?";

        PreparedStatement psCek =
        conn.prepareStatement(cek);

        psCek.setString(1, k.getKategori());
        psCek.setString(2, k.getBrand());

        ResultSet rs = psCek.executeQuery();

        if(rs.next()){

            JOptionPane.showMessageDialog(null,
            "Tidak boleh ada kombinasi kategori dan brand yang sama.");

            return;
        }

        String sql =
        "INSERT INTO kategori(kategori,brand) VALUES(?,?)";

        PreparedStatement ps =
        conn.prepareStatement(sql);

        ps.setString(1,k.getKategori());
        ps.setString(2,k.getBrand());

        ps.executeUpdate();

        JOptionPane.showMessageDialog(null,
        "Data berhasil disimpan.");

    }catch(Exception e){

        JOptionPane.showMessageDialog(null,e.getMessage());
    }
}
   
    public void delete(int kode) {

    try{
        
        String cek = 
        "SELECT COUNT(*) jumlah FROM produk WHERE kode_produk=?";
        
        PreparedStatement psCek = conn.prepareStatement(cek);
        psCek.setInt(1, kode);
        
        ResultSet rs = psCek.executeQuery();
        
        if (rs.next() && rs.getInt("jumlah") > 0){
            
            JOptionPane.showMessageDialog(null,
                    "Kategori tidak dapat dihapus karena masih ada kategori yang berelasi");
            
            return;
        }

        String sql =
        "DELETE FROM kategori WHERE kode=?";

        PreparedStatement ps =
        conn.prepareStatement(sql);

        ps.setInt(1,kode);

        ps.executeUpdate();

        JOptionPane.showMessageDialog(null,
        "Data berhasil dihapus.");

    }catch(Exception e){

        JOptionPane.showMessageDialog(null,
        e.getMessage());
    }
}
    
    public void update(Kategori k) {
 
    try {

        String sql = "UPDATE kategori SET kategori=?, brand=? WHERE kode=?";

        PreparedStatement ps = conn.prepareStatement(sql);

        ps.setString(1, k.getKategori());
        ps.setString(2, k.getBrand());
        ps.setInt(3, k.getKode());

        int hasil = ps.executeUpdate();

        if (hasil > 0) {
            JOptionPane.showMessageDialog(null, "Data berhasil diupdate.");
        }

    } catch (Exception e) {
        JOptionPane.showMessageDialog(null, e.getMessage());
    }
} 
    
    public List<Kategori> getAllKategori() {
        List<Kategori> list = new ArrayList<>();

    try {

        String sql = "SELECT * FROM kategori";
        PreparedStatement ps = conn.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();

        while (rs.next()) {

            Kategori k = new Kategori();

            k.setKode(rs.getInt("kode"));
            k.setKategori(rs.getString("kategori"));
            k.setBrand(rs.getString("brand"));

            list.add(k);
        }

    } catch (Exception e) {
        JOptionPane.showMessageDialog(null, e.getMessage());
    }

    return list;
    }
    
    public int getKodeKategori(String namaKategori) {

    int kode = 0;

    try {

        String sql = "SELECT kode FROM kategori WHERE kategori = ?";

        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setString(1, namaKategori);

        ResultSet rs = ps.executeQuery();

        if (rs.next()) {
            kode = rs.getInt("kode");
        }

    } catch (Exception e) {
        JOptionPane.showMessageDialog(null, e.getMessage());
    }

    return kode;
}
    public boolean cekKategoriBrand(String kategori, String brand) {

    try {

        String sql = "SELECT * FROM kategori "
                   + "WHERE kategori=? AND brand=?";

        PreparedStatement ps = conn.prepareStatement(sql);

        ps.setString(1, kategori);
        ps.setString(2, brand);

        ResultSet rs = ps.executeQuery();

        return rs.next();

    } catch (Exception e) {
        JOptionPane.showMessageDialog(null, e.getMessage());
        
        
         return false;
    }
  }
}
