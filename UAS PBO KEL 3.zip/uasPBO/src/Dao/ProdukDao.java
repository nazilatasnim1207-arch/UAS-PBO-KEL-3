/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package Dao;

import Model.Produk;
import Util.DBConection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Nazila T
 * NIM = 25104410005
 * Kelas = Teknik Informatika
 */
public class ProdukDao {
    
    Connection conn = DBConection.getKoneksi();

    // LOAD DATA
    public void loadData(JTable table) {

    DefaultTableModel model = new DefaultTableModel();

    model.addColumn("Kode");
    model.addColumn("Kode Produk"); // FK (akan disembunyikan)
    model.addColumn("Nama Produk");
    model.addColumn("Harga");
    model.addColumn("Stock");
    model.addColumn("Kategori");
    model.addColumn("Brand");

    try {

        String sql = "SELECT p.kode, p.kode_produk, p.nama_produk, p.harga, p.stock, "
                + "k.kategori, k.brand "
                + "FROM produk p "
                + "INNER JOIN kategori k "
                + "ON p.kode_produk = k.kode";

        PreparedStatement ps = conn.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();

        while (rs.next()) {

            model.addRow(new Object[]{
                rs.getInt("kode"),
                rs.getInt("kode_produk"),
                rs.getString("nama_produk"),
                rs.getInt("harga"),
                rs.getInt("stock"),
                rs.getString("kategori"),
                rs.getString("brand")
            });

        }

        table.setModel(model);

        // sembunyikan kolom kode_produk
        table.getColumnModel().getColumn(1).setMinWidth(0);
        table.getColumnModel().getColumn(1).setMaxWidth(0);
        table.getColumnModel().getColumn(1).setWidth(0);

    } catch (Exception e) {
        JOptionPane.showMessageDialog(null, e.getMessage());
      }
   }

    // INSERT
    public void insert(Produk p) {

        try {
            String sql = "INSERT INTO produk(kode_produk,nama_produk,harga,stock) VALUES(?,?,?,?)";

            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, p.getKodeProduk());
            ps.setString(2, p.getNama());
            ps.setInt(3, p.getHarga());
            ps.setInt(4, p.getStock());

            ps.executeUpdate();

            JOptionPane.showMessageDialog(null, "Data berhasil disimpan");

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
         }
    }

    // UPDATE
    public void update(Produk p) {

        try {

            String sql = "UPDATE produk SET kode_produk=?, nama_produk=?, harga=?, stock=? WHERE kode=?";

            PreparedStatement ps = conn.prepareStatement(sql);

            ps.setInt(1, p.getKodeProduk());
            ps.setString(2, p.getNama());
            ps.setInt(3, p.getHarga());
            ps.setInt(4, p.getStock());
            ps.setInt(5, p.getKode());

            ps.executeUpdate();

            JOptionPane.showMessageDialog(null, "Data berhasil diupdate");

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
         }
    }

    // DELETE
    public void delete(int kode) {

        try {

            String sql = "DELETE FROM produk WHERE kode=?";

            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, kode);

            ps.executeUpdate();

            JOptionPane.showMessageDialog(null, "Data berhasil dihapus");

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }
}
