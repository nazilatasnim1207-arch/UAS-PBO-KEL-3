/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package Model;

/**
 *
 * @author Nazila T
 * NIM = 25104410005
 * Kelas = Teknik Informatika
 */
public class Produk {
    private int kode;
    private int kode_produk;
    private String nama_produk;
    private int harga;
    private int stock;

    public Produk() {
    }

    public Produk(int kode, int kodeProduk, String nama, int harga, int stock) {
        this.kode = kode;
        this.kode_produk = kodeProduk;
        this.nama_produk = nama;
        this.harga = harga;
        this.stock = stock;
    }

    public int getKode() {
        return kode;
    }

    public void setKode(int kode) {
        this.kode = kode;
    }

    public int getKodeProduk() {
        return kode_produk;
    }

    public void setKodeProduk(int kodeProduk) {
        this.kode_produk = kodeProduk;
    }

    public String getNama() {
        return nama_produk;
    }

    public void setNama(String nama) {
        this.nama_produk = nama;
    }

    public int getHarga() {
        return harga;
    }

    public void setHarga(int harga) {
        this.harga = harga;
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }
}


